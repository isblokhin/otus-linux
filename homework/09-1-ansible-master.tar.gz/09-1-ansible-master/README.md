# Описание

Стенд для практики на уроке "Автоматизация с помощью Ansible"

## Quick Start

Для запуска стенда достаточно дать:

```
vagrant up
```

Поднимется две машины:

* `ansible` - с уже установленным пакетом `ansible` и ключом для доступа к хосту `web`
* `web` - управляемый хост с которым будем экспериментировать

Задание находится по ссылке: https://docs.google.com/document/d/1xaQZVyzw37kbZjk43sXo3xHV74ukGeQpFeyLwIwTNwQ/edit?usp=sharing